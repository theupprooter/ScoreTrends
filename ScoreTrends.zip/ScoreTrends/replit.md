# Overview

My Score Trends is a full-stack academic performance tracking application that allows students to monitor their test scores, visualize trends, and gain insights through analytics. The application features a React frontend with a modern UI built using shadcn/ui components, and an Express.js backend. It includes comprehensive analytics with statistical calculations, data visualization through charts, and CSV import/export functionality for score management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript using Vite as the build tool
- **UI Library**: shadcn/ui components with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with custom design tokens and dark mode support
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React hooks for local state, TanStack Query for server state management
- **Form Handling**: React Hook Form with Zod validation for type-safe form schemas

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API structure with route registration pattern
- **Storage Interface**: Abstract storage layer with in-memory implementation (ready for database integration)
- **Development**: Hot reload with Vite integration for seamless development experience

## Data Storage Solutions
- **Current**: In-memory storage with Map-based data structures
- **Database Ready**: Drizzle ORM configured for PostgreSQL with migration support
- **Client Storage**: localStorage for browser-based data persistence
- **Schema**: Strongly typed with Zod validation for data integrity

## Key Features
- **Score Management**: Add, view, and delete test scores with validation
- **Analytics Dashboard**: Moving averages, trend analysis, linear regression, and performance forecasting
- **Data Visualization**: Interactive charts using Recharts library
- **Import/Export**: CSV file handling for bulk data operations
- **Responsive Design**: Mobile-first approach with responsive navigation

## External Dependencies

- **Database**: Neon Database (PostgreSQL) with connection pooling via @neondatabase/serverless
- **ORM**: Drizzle ORM for type-safe database operations and migrations
- **UI Components**: Radix UI primitives for accessible component foundation
- **Charts**: Recharts library for data visualization and analytics
- **Validation**: Zod for runtime type checking and schema validation
- **Forms**: React Hook Form with Hookform resolvers for form management
- **Styling**: Tailwind CSS with class-variance-authority for component variants
- **Development**: Replit-specific plugins for cartographer and dev banner integration