import { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertScoreSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { addScore, getScores, deleteScore, clearAllScores } from "@/lib/storage";
import { exportToCSV, importFromCSV } from "@/lib/csv";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Download, Upload, Trash } from "lucide-react";
import { z } from "zod";

const formSchema = insertScoreSchema.extend({
  subject: z.string().min(1, "Subject is required"),
  testTitle: z.string().min(1, "Test title is required"),
  date: z.string().min(1, "Date is required"),
  maxMarks: z.number().min(1, "Max marks must be at least 1"),
  score: z.number().min(0, "Score cannot be negative"),
});

export default function AddScores() {
  const [scores, setScores] = useState(getScores());
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      subject: "",
      testTitle: "",
      date: new Date().toISOString().split('T')[0],
      maxMarks: 100,
      score: 0,
      notes: "",
    },
  });

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    const percentage = Math.round((values.score / values.maxMarks) * 100);
    
    // Validate that score doesn't exceed maxMarks
    if (values.score > values.maxMarks) {
      toast({
        title: "Invalid score",
        description: "Score cannot be greater than max marks.",
        variant: "destructive",
      });
      return;
    }

    const newScore = addScore({ ...values, notes: values.notes || null, percentage });
    setScores(getScores());
    form.reset({
      subject: "",
      testTitle: "",
      date: new Date().toISOString().split('T')[0],
      maxMarks: 100,
      score: 0,
      notes: "",
    });

    toast({
      title: "Score added successfully!",
      description: `${values.subject} - ${values.testTitle}: ${percentage}%`,
    });
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this score?")) {
      deleteScore(id);
      setScores(getScores());
      toast({
        title: "Score deleted",
        description: "The score has been removed successfully.",
      });
    }
  };

  const handleExport = () => {
    try {
      exportToCSV(scores);
      toast({
        title: "Export successful",
        description: "Your scores have been exported to CSV.",
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: error instanceof Error ? error.message : "Failed to export data.",
        variant: "destructive",
      });
    }
  };

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const importedScores = await importFromCSV(file);
      
      // Add imported scores
      importedScores.forEach(scoreData => {
        addScore(scoreData);
      });
      
      setScores(getScores());
      toast({
        title: "Import successful",
        description: `${importedScores.length} scores imported successfully.`,
      });
    } catch (error) {
      toast({
        title: "Import failed",
        description: error instanceof Error ? error.message : "Failed to import CSV file.",
        variant: "destructive",
      });
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleClearAll = () => {
    if (confirm("Are you sure you want to clear all data? This action cannot be undone.")) {
      clearAllScores();
      setScores([]);
      toast({
        title: "Data cleared",
        description: "All scores have been removed.",
      });
    }
  };

  const getPercentageVariant = (percentage: number) => {
    if (percentage >= 90) return "default";
    if (percentage >= 75) return "secondary";
    return "destructive";
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Add Your Scores</h2>
        <p className="text-muted-foreground">Enter your test scores to track your academic progress over time.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Score Entry Form */}
        <Card className="rounded-xl shadow-md">
          <CardHeader>
            <CardTitle>New Score Entry</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="subject"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subject</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., Mathematics, Physics, Chemistry"
                          data-testid="input-subject"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="testTitle"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Test Title</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="e.g., Mid-term Exam, Quiz 1"
                          data-testid="input-test-title"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          data-testid="input-date"
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="maxMarks"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Max Marks</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="1"
                            data-testid="input-max-marks"
                            {...field}
                            onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="score"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Score</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="0"
                            data-testid="input-score"
                            {...field}
                            onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Any additional notes about this test..."
                          data-testid="input-notes"
                          {...field}
                          value={field.value || ''}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full rounded-lg"
                  data-testid="button-add-score"
                >
                  Add Score
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Data Management */}
        <Card className="rounded-xl shadow-md">
          <CardHeader>
            <CardTitle>Data Management</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Import CSV</label>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleImport}
                className="w-full px-3 py-2 border border-border rounded-lg focus:ring-2 focus:ring-ring focus:border-transparent transition-colors"
                data-testid="input-csv-import"
              />
              <p className="text-xs text-muted-foreground mt-2">
                Expected format: Subject,Test Title,Date,Max Marks,Score,Notes
              </p>
            </div>
            
            <Button
              onClick={handleExport}
              disabled={scores.length === 0}
              variant="secondary"
              className="w-full rounded-lg"
              data-testid="button-export-csv"
            >
              <Download className="w-4 h-4 mr-2" />
              Export to CSV
            </Button>
            
            <Button
              onClick={handleClearAll}
              disabled={scores.length === 0}
              variant="outline"
              className="w-full rounded-lg"
              data-testid="button-clear-data"
            >
              <Trash className="w-4 h-4 mr-2" />
              Clear All Data
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Scores Table */}
      <Card className="mt-8 rounded-xl shadow-md">
        <CardHeader>
          <CardTitle>Your Scores</CardTitle>
          <CardDescription>All your entered test scores</CardDescription>
        </CardHeader>
        <CardContent>
          {scores.length === 0 ? (
            <div className="p-8 text-center text-muted-foreground" data-testid="no-scores-message">
              <p>No scores added yet. Start by adding your first test score above!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Subject</TableHead>
                    <TableHead>Test</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Percentage</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scores
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map((score) => (
                      <TableRow key={score.id} data-testid={`score-row-${score.id}`}>
                        <TableCell className="font-medium">{score.subject}</TableCell>
                        <TableCell>{score.testTitle}</TableCell>
                        <TableCell className="text-muted-foreground">{score.date}</TableCell>
                        <TableCell>{score.score}/{score.maxMarks}</TableCell>
                        <TableCell>
                          <Badge variant={getPercentageVariant(score.percentage)}>
                            {score.percentage}%
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground max-w-xs truncate">
                          {score.notes || "-"}
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(score.id)}
                            data-testid={`button-delete-${score.id}`}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
