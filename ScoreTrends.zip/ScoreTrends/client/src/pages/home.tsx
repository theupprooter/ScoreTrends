import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { generateDemoData } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { toast } = useToast();

  const handleDemoData = () => {
    generateDemoData();
    toast({
      title: "Demo data loaded!",
      description: "10 sample test scores have been added to help you explore the app.",
    });
  };

  return (
    <section className="bg-gradient-to-br from-background to-accent">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 leading-tight">
            Track Your Academic
            <span className="text-primary"> Progress</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto leading-relaxed">
            Monitor your test scores, visualize trends, and gain insights into your academic performance with powerful analytics and forecasting.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/add-scores">
              <Button 
                size="lg" 
                className="px-8 py-3 rounded-xl font-medium shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 transition-all"
                data-testid="button-start-adding-scores"
              >
                Start Adding Scores
              </Button>
            </Link>
            <Button
              variant="outline"
              size="lg"
              onClick={handleDemoData}
              className="px-8 py-3 rounded-xl font-medium"
              data-testid="button-load-demo-data"
            >
              Load Demo Data
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
