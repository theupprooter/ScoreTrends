import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { getScores } from "@/lib/storage";
import { calculateAnalytics, AnalyticsData } from "@/lib/statistics";
import { Link } from "wouter";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from "recharts";
import { TrendingUp, TrendingDown, Target, BarChart3, Award, AlertTriangle } from "lucide-react";

export default function Analytics() {
  const [scores] = useState(getScores());
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);

  useEffect(() => {
    if (scores.length > 0) {
      setAnalytics(calculateAnalytics(scores));
    }
  }, [scores]);

  const hasEnoughData = scores.length >= 5;

  if (!hasEnoughData) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">Analytics Dashboard</h2>
          <p className="text-muted-foreground">Detailed insights into your academic performance trends.</p>
        </div>

        <Card className="rounded-xl shadow-md p-12 text-center" data-testid="insufficient-data-message">
          <CardContent className="pt-6">
            <BarChart3 className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <CardTitle className="text-xl font-semibold text-foreground mb-2">Insufficient Data</CardTitle>
            <CardDescription className="mb-6">
              You need at least 5 scores to view detailed analytics and trends.
            </CardDescription>
            <Link href="/add-scores">
              <Button data-testid="button-add-more-scores">
                Add More Scores
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!analytics) return null;

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'improving':
        return <TrendingUp className="w-6 h-6 text-success" />;
      case 'declining':
        return <TrendingDown className="w-6 h-6 text-destructive" />;
      default:
        return <Target className="w-6 h-6 text-warning" />;
    }
  };

  const getTrendColor = (trend: string) => {
    switch (trend) {
      case 'improving':
        return 'text-success';
      case 'declining':
        return 'text-destructive';
      default:
        return 'text-warning';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Analytics Dashboard</h2>
        <p className="text-muted-foreground">Detailed insights into your academic performance trends.</p>
      </div>

      <div className="space-y-8">
        {/* Performance Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="rounded-xl shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Average Score</p>
                  <p className="text-2xl font-bold text-foreground" data-testid="text-average-score">
                    {analytics.averageScore}%
                  </p>
                </div>
                <div className="p-3 bg-primary/10 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-xl shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Tests</p>
                  <p className="text-2xl font-bold text-foreground" data-testid="text-total-tests">
                    {analytics.totalTests}
                  </p>
                </div>
                <div className="p-3 bg-secondary/10 rounded-lg">
                  <Award className="w-6 h-6 text-secondary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-xl shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Trend</p>
                  <p className={`text-2xl font-bold capitalize ${getTrendColor(analytics.trend)}`} data-testid="text-trend">
                    {analytics.trend}
                  </p>
                </div>
                <div className={`p-3 rounded-lg ${
                  analytics.trend === 'improving' ? 'bg-success/10' :
                  analytics.trend === 'declining' ? 'bg-destructive/10' : 'bg-warning/10'
                }`}>
                  {getTrendIcon(analytics.trend)}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-xl shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Next Forecast</p>
                  <p className="text-2xl font-bold text-foreground" data-testid="text-forecast">
                    {analytics.forecast}%
                  </p>
                </div>
                <div className="p-3 bg-warning/10 rounded-lg">
                  <Target className="w-6 h-6 text-warning" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Score Trends Chart */}
        <Card className="rounded-xl shadow-md">
          <CardHeader>
            <CardTitle>Score Trends Over Time</CardTitle>
            <CardDescription>Your test scores with 3-period moving average</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80" data-testid="score-trends-chart">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={analytics.movingAverages}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    name="Score"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="movingAverage" 
                    stroke="hsl(var(--secondary))" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    name="Moving Average"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Subject Performance & Statistics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="rounded-xl shadow-md">
            <CardHeader>
              <CardTitle>Subject Performance</CardTitle>
              <CardDescription>Average scores by subject</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics.subjectPerformance.map((subject, index) => (
                  <div key={subject.subject} className="flex items-center justify-between">
                    <span className="text-sm font-medium text-foreground">{subject.subject}</span>
                    <div className="flex items-center space-x-2">
                      <Progress 
                        value={subject.average} 
                        className="w-32" 
                        data-testid={`progress-${subject.subject}`}
                      />
                      <span className="text-sm text-muted-foreground min-w-[3rem]">
                        {subject.average}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-xl shadow-md">
            <CardHeader>
              <CardTitle>Statistical Analysis</CardTitle>
              <CardDescription>Detailed performance metrics and outlier detection</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 gap-6">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">Standard Deviation</p>
                  <p className="text-2xl font-bold text-foreground" data-testid="text-std-dev">
                    {analytics.standardDeviation}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">Outliers Detected</p>
                  <p className="text-2xl font-bold text-warning" data-testid="text-outliers">
                    {analytics.outliers.length}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">Consistency Score</p>
                  <p className="text-2xl font-bold text-success" data-testid="text-consistency">
                    {analytics.standardDeviation < 10 ? 'Excellent' : 
                     analytics.standardDeviation < 20 ? 'Good' : 'Needs Work'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Subject Performance Chart */}
        <Card className="rounded-xl shadow-md">
          <CardHeader>
            <CardTitle>Subject Performance Comparison</CardTitle>
            <CardDescription>Average performance across different subjects</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64" data-testid="subject-performance-chart">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={analytics.subjectPerformance}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="subject" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Bar dataKey="average" fill="hsl(var(--primary))" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Insights */}
        <Card className="rounded-xl shadow-md">
          <CardHeader>
            <CardTitle>Performance Insights</CardTitle>
            <CardDescription>AI-generated analysis of your performance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.insights.map((insight, index) => (
                <div key={index} className="flex items-start space-x-3" data-testid={`insight-${index}`}>
                  <div className="flex-shrink-0 w-2 h-2 bg-primary rounded-full mt-2"></div>
                  <p className="text-foreground">{insight}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
