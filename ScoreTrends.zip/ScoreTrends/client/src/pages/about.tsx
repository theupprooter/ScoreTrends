import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart3, TrendingUp, Target, Shield } from "lucide-react";

export default function About() {
  const features = [
    {
      icon: <BarChart3 className="w-6 h-6 text-primary" />,
      title: "Track Performance",
      description: "Monitor your test scores across different subjects and time periods with detailed analytics.",
      bgColor: "bg-primary/10",
    },
    {
      icon: <TrendingUp className="w-6 h-6 text-secondary" />,
      title: "Trend Analysis",
      description: "Identify patterns in your performance with advanced statistical analysis and forecasting.",
      bgColor: "bg-secondary/10",
    },
    {
      icon: <Target className="w-6 h-6 text-success" />,
      title: "Insights",
      description: "Get personalized recommendations based on your performance patterns and study habits.",
      bgColor: "bg-success/10",
    },
    {
      icon: <Shield className="w-6 h-6 text-warning" />,
      title: "Privacy First",
      description: "All your data is stored locally in your browser. We never send your scores to external servers.",
      bgColor: "bg-warning/10",
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-foreground mb-4">About My Score Trends</h2>
        <p className="text-xl text-muted-foreground">Empowering students with data-driven insights</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        {features.map((feature, index) => (
          <Card key={index} className="rounded-xl shadow-md">
            <CardHeader>
              <div className={`w-12 h-12 ${feature.bgColor} rounded-lg flex items-center justify-center mb-4`}>
                {feature.icon}
              </div>
              <CardTitle className="text-lg">{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-muted-foreground">
                {feature.description}
              </CardDescription>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="rounded-xl shadow-md text-center">
        <CardContent className="p-8">
          <CardTitle className="text-xl font-semibold text-foreground mb-4">
            Ready to Start Tracking?
          </CardTitle>
          <CardDescription className="text-muted-foreground mb-6">
            Begin your journey to better academic performance with data-driven insights.
          </CardDescription>
          <Link href="/add-scores">
            <Button size="lg" className="px-8 py-3 rounded-xl font-medium" data-testid="button-get-started">
              Get Started Now
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Footer */}
      <footer className="mt-16 pt-8 border-t border-border">
        <div className="text-center">
          <p className="text-muted-foreground">
            &copy; 2024 My Score Trends. Built with passion for education.
          </p>
        </div>
      </footer>
    </div>
  );
}
