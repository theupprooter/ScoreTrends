import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

export default function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Home", dataTestId: "nav-home" },
    { href: "/add-scores", label: "Add Scores", dataTestId: "nav-add-scores" },
    { href: "/analytics", label: "Analytics", dataTestId: "nav-analytics" },
    { href: "/about", label: "About", dataTestId: "nav-about" },
  ];

  return (
    <nav className="sticky top-0 bg-card border-b border-border shadow-sm z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/">
              <h1 className="text-xl font-bold text-primary cursor-pointer" data-testid="logo">
                My Score Trends
              </h1>
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              {navItems.map(({ href, label, dataTestId }) => {
                const isActive = location === href;
                return (
                  <Link key={href} href={href}>
                    <a
                      className={cn(
                        "transition-colors cursor-pointer",
                        isActive
                          ? "text-primary font-medium border-b-2 border-primary pb-1"
                          : "text-muted-foreground hover:text-foreground"
                      )}
                      data-testid={dataTestId}
                    >
                      {label}
                    </a>
                  </Link>
                );
              })}
            </div>
          </div>
          <div className="md:hidden">
            <button 
              className="text-muted-foreground hover:text-foreground"
              data-testid="mobile-menu-button"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
}
