import { Score } from "@shared/schema";

export function exportToCSV(scores: Score[]): void {
  if (scores.length === 0) {
    throw new Error("No data to export");
  }
  
  const headers = ['Subject', 'Test Title', 'Date', 'Max Marks', 'Score', 'Notes'];
  const csvContent = [
    headers.join(','),
    ...scores.map(score => [
      `"${score.subject}"`,
      `"${score.testTitle}"`,
      score.date,
      score.maxMarks,
      score.score,
      `"${score.notes || ''}"`,
    ].join(','))
  ].join('\n');
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', 'my_score_trends.csv');
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function importFromCSV(file: File): Promise<Omit<Score, 'id' | 'createdAt'>[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (event) => {
      try {
        const csv = event.target?.result as string;
        const lines = csv.split('\n').filter(line => line.trim());
        
        if (lines.length < 2) {
          throw new Error("CSV file must contain at least a header row and one data row");
        }
        
        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        const expectedHeaders = ['Subject', 'Test Title', 'Date', 'Max Marks', 'Score', 'Notes'];
        
        // Validate headers
        const hasRequiredHeaders = expectedHeaders.slice(0, 5).every(header => 
          headers.some(h => h.toLowerCase().includes(header.toLowerCase()))
        );
        
        if (!hasRequiredHeaders) {
          throw new Error("CSV must contain columns: Subject, Test Title, Date, Max Marks, Score, Notes (optional)");
        }
        
        const importedScores = lines.slice(1).map(line => {
          const values = line.split(',').map(v => v.trim().replace(/"/g, ''));
          
          const subject = values[0];
          const testTitle = values[1];
          const date = values[2];
          const maxMarks = parseInt(values[3]);
          const score = parseInt(values[4]);
          const notes = values[5] || '';
          
          if (!subject || !testTitle || !date || isNaN(maxMarks) || isNaN(score)) {
            throw new Error("Invalid data format in CSV file");
          }
          
          return {
            subject,
            testTitle,
            date,
            maxMarks,
            score,
            notes,
            percentage: Math.round((score / maxMarks) * 100),
          };
        });
        
        resolve(importedScores);
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = () => {
      reject(new Error("Error reading file"));
    };
    
    reader.readAsText(file);
  });
}
