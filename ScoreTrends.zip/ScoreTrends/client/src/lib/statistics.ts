import { Score } from "@shared/schema";

export interface AnalyticsData {
  averageScore: number;
  totalTests: number;
  trend: 'improving' | 'declining' | 'stable';
  forecast: number;
  standardDeviation: number;
  outliers: Score[];
  subjectPerformance: { subject: string; average: number; color: string }[];
  movingAverages: { date: string; score: number; movingAverage: number }[];
  insights: string[];
}

export function calculateMovingAverage(scores: Score[], window: number = 3): { date: string; score: number; movingAverage: number }[] {
  const sortedScores = [...scores].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  return sortedScores.map((score, index) => {
    const start = Math.max(0, index - window + 1);
    const subset = sortedScores.slice(start, index + 1);
    const average = subset.reduce((sum, s) => sum + s.percentage, 0) / subset.length;
    
    return {
      date: score.date,
      score: score.percentage,
      movingAverage: Math.round(average * 100) / 100,
    };
  });
}

export function calculateLinearRegression(scores: Score[]): { slope: number; intercept: number } {
  const sortedScores = [...scores].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const n = sortedScores.length;
  
  if (n < 2) return { slope: 0, intercept: 0 };
  
  const xValues = sortedScores.map((_, index) => index);
  const yValues = sortedScores.map(score => score.percentage);
  
  const xMean = xValues.reduce((sum, x) => sum + x, 0) / n;
  const yMean = yValues.reduce((sum, y) => sum + y, 0) / n;
  
  const numerator = xValues.reduce((sum, x, i) => sum + (x - xMean) * (yValues[i] - yMean), 0);
  const denominator = xValues.reduce((sum, x) => sum + Math.pow(x - xMean, 2), 0);
  
  const slope = denominator === 0 ? 0 : numerator / denominator;
  const intercept = yMean - slope * xMean;
  
  return { slope, intercept };
}

export function getTrend(scores: Score[]): 'improving' | 'declining' | 'stable' {
  if (scores.length < 3) return 'stable';
  
  const { slope } = calculateLinearRegression(scores);
  
  if (slope > 1) return 'improving';
  if (slope < -1) return 'declining';
  return 'stable';
}

export function calculateStandardDeviation(scores: Score[]): number {
  if (scores.length < 2) return 0;
  
  const percentages = scores.map(score => score.percentage);
  const mean = percentages.reduce((sum, p) => sum + p, 0) / percentages.length;
  const variance = percentages.reduce((sum, p) => sum + Math.pow(p - mean, 2), 0) / percentages.length;
  
  return Math.sqrt(variance);
}

export function detectOutliers(scores: Score[]): Score[] {
  if (scores.length < 4) return [];
  
  const percentages = scores.map(score => score.percentage);
  const mean = percentages.reduce((sum, p) => sum + p, 0) / percentages.length;
  const stdDev = calculateStandardDeviation(scores);
  
  const threshold = 2 * stdDev; // 2 standard deviations
  
  return scores.filter(score => Math.abs(score.percentage - mean) > threshold);
}

export function forecastNextScore(scores: Score[]): number {
  if (scores.length < 3) return 0;
  
  const { slope, intercept } = calculateLinearRegression(scores);
  const nextIndex = scores.length;
  const forecast = slope * nextIndex + intercept;
  
  return Math.max(0, Math.min(100, Math.round(forecast * 100) / 100));
}

export function getSubjectPerformance(scores: Score[]): { subject: string; average: number; color: string }[] {
  const subjectMap = new Map<string, number[]>();
  
  scores.forEach(score => {
    if (!subjectMap.has(score.subject)) {
      subjectMap.set(score.subject, []);
    }
    subjectMap.get(score.subject)!.push(score.percentage);
  });
  
  const colors = ['#2563eb', '#9333ea', '#16a34a', '#f59e0b', '#dc2626'];
  let colorIndex = 0;
  
  return Array.from(subjectMap.entries()).map(([subject, percentages]) => {
    const average = percentages.reduce((sum, p) => sum + p, 0) / percentages.length;
    const color = colors[colorIndex % colors.length];
    colorIndex++;
    
    return {
      subject,
      average: Math.round(average * 100) / 100,
      color,
    };
  });
}

export function generateInsights(scores: Score[]): string[] {
  const insights: string[] = [];
  
  if (scores.length < 3) {
    insights.push("Add more scores to get detailed insights about your performance.");
    return insights;
  }
  
  const trend = getTrend(scores);
  const averageScore = scores.reduce((sum, score) => sum + score.percentage, 0) / scores.length;
  const outliers = detectOutliers(scores);
  const subjectPerformance = getSubjectPerformance(scores);
  
  // Trend insights
  if (trend === 'improving') {
    insights.push("🎉 Your performance shows a consistent upward trend. Keep up the excellent work!");
  } else if (trend === 'declining') {
    insights.push("⚠️ Your scores have been declining recently. Consider reviewing your study methods.");
  } else {
    insights.push("📊 Your performance is stable. Consider setting new challenges to improve further.");
  }
  
  // Performance level insights
  if (averageScore >= 90) {
    insights.push("🌟 Outstanding performance! You're consistently scoring in the excellent range.");
  } else if (averageScore >= 75) {
    insights.push("👍 Good performance overall. With focused effort, you can reach excellence.");
  } else if (averageScore >= 60) {
    insights.push("📈 Your performance is satisfactory but has room for improvement.");
  } else {
    insights.push("🎯 Focus on understanding core concepts to improve your scores significantly.");
  }
  
  // Subject-specific insights
  if (subjectPerformance.length > 1) {
    const bestSubject = subjectPerformance.reduce((best, current) => 
      current.average > best.average ? current : best
    );
    const worstSubject = subjectPerformance.reduce((worst, current) => 
      current.average < worst.average ? current : worst
    );
    
    if (bestSubject.average - worstSubject.average > 15) {
      insights.push(`💪 ${bestSubject.subject} is your strongest subject. Consider applying similar study techniques to ${worstSubject.subject}.`);
    }
  }
  
  // Outlier insights
  if (outliers.length > 0) {
    insights.push(`🔍 ${outliers.length} test score(s) were significantly different from your average. Review these for learning opportunities.`);
  }
  
  // Consistency insights
  const stdDev = calculateStandardDeviation(scores);
  if (stdDev < 10) {
    insights.push("🎯 Your performance is very consistent. This shows reliable preparation habits.");
  } else if (stdDev > 20) {
    insights.push("📊 Your scores vary significantly. Work on developing more consistent study habits.");
  }
  
  return insights;
}

export function calculateAnalytics(scores: Score[]): AnalyticsData {
  if (scores.length === 0) {
    return {
      averageScore: 0,
      totalTests: 0,
      trend: 'stable',
      forecast: 0,
      standardDeviation: 0,
      outliers: [],
      subjectPerformance: [],
      movingAverages: [],
      insights: [],
    };
  }
  
  return {
    averageScore: Math.round((scores.reduce((sum, score) => sum + score.percentage, 0) / scores.length) * 100) / 100,
    totalTests: scores.length,
    trend: getTrend(scores),
    forecast: forecastNextScore(scores),
    standardDeviation: Math.round(calculateStandardDeviation(scores) * 100) / 100,
    outliers: detectOutliers(scores),
    subjectPerformance: getSubjectPerformance(scores),
    movingAverages: calculateMovingAverage(scores),
    insights: generateInsights(scores),
  };
}
