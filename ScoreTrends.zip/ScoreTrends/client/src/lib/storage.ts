import { Score } from "@shared/schema";

const STORAGE_KEY = 'myScoreTrends_scores';

export function getScores(): Score[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error loading scores from localStorage:', error);
    return [];
  }
}

export function saveScores(scores: Score[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(scores));
  } catch (error) {
    console.error('Error saving scores to localStorage:', error);
  }
}

export function addScore(score: Omit<Score, 'id' | 'createdAt'>): Score {
  const newScore: Score = {
    ...score,
    id: Date.now().toString(),
    createdAt: new Date(),
  };
  
  const scores = getScores();
  scores.push(newScore);
  saveScores(scores);
  
  return newScore;
}

export function deleteScore(id: string): void {
  const scores = getScores().filter(score => score.id !== id);
  saveScores(scores);
}

export function clearAllScores(): void {
  localStorage.removeItem(STORAGE_KEY);
}

export function generateDemoData(): Score[] {
  const demoScores: Score[] = [
    {
      id: "demo-1",
      subject: "Mathematics",
      testTitle: "Algebra Test",
      date: "2024-01-15",
      maxMarks: 100,
      score: 85,
      notes: "Good performance",
      percentage: 85,
      createdAt: new Date("2024-01-15"),
    },
    {
      id: "demo-2",
      subject: "Physics",
      testTitle: "Mechanics Quiz",
      date: "2024-01-20",
      maxMarks: 50,
      score: 42,
      notes: "Need more practice",
      percentage: 84,
      createdAt: new Date("2024-01-20"),
    },
    {
      id: "demo-3",
      subject: "Chemistry",
      testTitle: "Organic Chemistry",
      date: "2024-01-25",
      maxMarks: 100,
      score: 92,
      notes: "Excellent work",
      percentage: 92,
      createdAt: new Date("2024-01-25"),
    },
    {
      id: "demo-4",
      subject: "Mathematics",
      testTitle: "Calculus Test",
      date: "2024-02-01",
      maxMarks: 100,
      score: 78,
      notes: "Improved from last time",
      percentage: 78,
      createdAt: new Date("2024-02-01"),
    },
    {
      id: "demo-5",
      subject: "Physics",
      testTitle: "Thermodynamics",
      date: "2024-02-05",
      maxMarks: 75,
      score: 65,
      notes: "Average performance",
      percentage: 87,
      createdAt: new Date("2024-02-05"),
    },
    {
      id: "demo-6",
      subject: "Chemistry",
      testTitle: "Inorganic Chemistry",
      date: "2024-02-10",
      maxMarks: 100,
      score: 88,
      notes: "Good understanding",
      percentage: 88,
      createdAt: new Date("2024-02-10"),
    },
    {
      id: "demo-7",
      subject: "Mathematics",
      testTitle: "Statistics Quiz",
      date: "2024-02-15",
      maxMarks: 50,
      score: 47,
      notes: "Nearly perfect",
      percentage: 94,
      createdAt: new Date("2024-02-15"),
    },
    {
      id: "demo-8",
      subject: "Physics",
      testTitle: "Waves and Optics",
      date: "2024-02-20",
      maxMarks: 100,
      score: 83,
      notes: "Solid performance",
      percentage: 83,
      createdAt: new Date("2024-02-20"),
    },
    {
      id: "demo-9",
      subject: "Chemistry",
      testTitle: "Physical Chemistry",
      date: "2024-02-25",
      maxMarks: 100,
      score: 90,
      notes: "Great improvement",
      percentage: 90,
      createdAt: new Date("2024-02-25"),
    },
    {
      id: "demo-10",
      subject: "Mathematics",
      testTitle: "Geometry Test",
      date: "2024-03-01",
      maxMarks: 100,
      score: 95,
      notes: "Outstanding work",
      percentage: 95,
      createdAt: new Date("2024-03-01"),
    },
  ];
  
  saveScores(demoScores);
  return demoScores;
}
