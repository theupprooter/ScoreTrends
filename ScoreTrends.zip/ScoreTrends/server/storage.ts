import { type Score, type InsertScore } from "@shared/schema";
import { randomUUID } from "crypto";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getScore(id: string): Promise<Score | undefined>;
  getAllScores(): Promise<Score[]>;
  createScore(score: InsertScore): Promise<Score>;
  deleteScore(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private scores: Map<string, Score>;

  constructor() {
    this.scores = new Map();
  }

  async getScore(id: string): Promise<Score | undefined> {
    return this.scores.get(id);
  }

  async getAllScores(): Promise<Score[]> {
    return Array.from(this.scores.values());
  }

  async createScore(insertScore: InsertScore): Promise<Score> {
    const id = randomUUID();
    const percentage = Math.round((insertScore.score / insertScore.maxMarks) * 100);
    const score: Score = { 
      ...insertScore, 
      notes: insertScore.notes || null,
      id, 
      percentage,
      createdAt: new Date() 
    };
    this.scores.set(id, score);
    return score;
  }

  async deleteScore(id: string): Promise<void> {
    this.scores.delete(id);
  }
}

export const storage = new MemStorage();
